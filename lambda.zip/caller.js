const { handler } = require('.');

handler({
  body: JSON.stringify({
    fileId: '1ek7kq4Jn5QupqO7NezfEM80afsHvveuf',
    type: 'pdf',
    token:
      'ya29.A0AVA9y1s6gl-KRh0R04EbYr2SJAgGak2jmtJBoH-pGUGav6OajIcCtuN7j-YvuAN5i-DNQFMFNyWl7n_AJ7mBnu73CWToAjPkWuqRYupM_6u3nFBvY-FRsnYXPgjQ-UXHh7YQIdrryP4IvlS3jy5TnMNDjT0sVqEYUNnWUtBVEFTQVRBU0ZRRTY1ZHI4X2ZydXJKOFVZd2h0NXVBOXpMM3Jpdw0166',
  }),
});
